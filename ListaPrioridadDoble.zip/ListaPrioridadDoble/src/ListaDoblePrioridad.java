/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Takitos13
 */
public class ListaDoblePrioridad {
    private NodoPrioridad ini;
    private NodoPrioridad fin;
    
    public ListaDoblePrioridad(){
        ini=fin=null;
    }
    
    
    public boolean insertar (char v, int p){
        NodoPrioridad nuevo = new NodoPrioridad(v,p);
        if(nuevo==null) return false;
        if(hayListaDobleVacia()){
            ini=fin=nuevo;
            return true;
        }
        if(nuevo.prioridad>ini.prioridad){
            ini.ant=nuevo;
            nuevo.sig=ini;
            ini=nuevo;
            return true;
        }
        if(nuevo.prioridad<=fin.prioridad){
            fin.sig=nuevo;
            nuevo.ant=fin;
            fin=nuevo;
            return true;
        }
        NodoPrioridad t2;
        for(t2 = fin.ant; nuevo.prioridad>t2.prioridad; t2=t2.ant){
                
        }
        t2.sig.ant=nuevo;
        nuevo.sig=t2.sig;
        t2.sig=nuevo;
        nuevo.ant=t2;
        return true;
    }
    public boolean eliminar(){
        if(hayListaDobleVacia())return false;
        if(hayUnSoloNodo()){
            ini=fin=null;
            return true;
        }
        NodoPrioridad temp =ini;
        ini=temp.getSig();
        ini.setAnt(null);
        temp.setSig(null);
        temp=null;
       
        return true;
    }
      
    public boolean hayListaDobleVacia(){
        return ini==null && fin==null;
    }
    public boolean hayUnSoloNodo(){
        return ini==fin;
    }
    public  NodoPrioridad getIni(){
        return ini;
    }
}
