/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Takitos13
 */
public class NodoPrioridad {
    char valor;
    int prioridad;
    NodoPrioridad sig;
    NodoPrioridad ant;
    
    public NodoPrioridad(char v, int p){
        valor = v;
        prioridad = p;
        sig=null;
        ant=null;
    }

    public char getValor() {
        return valor;
    }

    public void setValor(char valor) {
        this.valor = valor;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public NodoPrioridad getSig() {
        return sig;
    }

    public void setSig(NodoPrioridad sig) {
        this.sig = sig;
    }

    public NodoPrioridad getAnt() {
        return ant;
    }

    public void setAnt(NodoPrioridad ant) {
        this.ant = ant;
    }
    @Override
    public String toString() {
        return valor + "," + prioridad;
    }
    
}
